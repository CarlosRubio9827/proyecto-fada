package Logic;

import Model.Encomienda;
import javax.swing.*;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import javax.swing.filechooser.FileNameExtensionFilter;

public class EntradaDatos {

    ArrayList<String> data = new ArrayList<>();
    int paquetes[][];
    ArrayList<Encomienda> enco;

    public EntradaDatos() {

        enco = new ArrayList<>();
        JFileChooser jFileChooser1 = new JFileChooser();
        FileNameExtensionFilter filter = new FileNameExtensionFilter("FADA FILES", "fada");
        jFileChooser1.setFileFilter(filter);
        try {
            jFileChooser1.setCurrentDirectory(new File("C:\\Users\\Lenovo\\Google Drive\\UNIVERSIDAD\\8 OCTAVO SEMESTRE\\FADA\\PROYECTO"));
            jFileChooser1.showOpenDialog(jFileChooser1);

            String patch = jFileChooser1.getSelectedFile().getAbsolutePath();
            BufferedReader br = new BufferedReader(new FileReader(patch));

            String cadena;

            while ((cadena = br.readLine()) != null) {
                data.add(cadena);
            }
        } catch (Exception e) {
            System.out.println("er" + e);
        }

        try {

            //Primer Linea
            String[] primerLinea = data.get(0).split(",");
            int ciudadx = Integer.parseInt(primerLinea[0]);
            int ciudady = Integer.parseInt(primerLinea[1]);
            int timerecorrer = Integer.parseInt(primerLinea[2]);
            //Segunda Linea
            String[] segundaLinea = data.get(1).split(",");
            int paquetes = Integer.parseInt(segundaLinea[0]);
            int tiempomensajero = Integer.parseInt(segundaLinea[1]);
            //Tercer Linea                 
            String[] terceraLinea = data.get(2).split(",");
            int ubicacionOficinax = Integer.parseInt(terceraLinea[0]);
            int ubicacionOficinay = Integer.parseInt(terceraLinea[1]);
            //Lineas Siguientes
            System.out.println("OFICINA " + ubicacionOficinax + "," + ubicacionOficinay + " paquetes=" + paquetes);
            for (int j = 2; j < data.size(); j++) {
                String[] lineasSiguientes = data.get(j).split(",");
                int ubicacionx = Integer.parseInt(lineasSiguientes[0]);
                int ubicaciony = Integer.parseInt(lineasSiguientes[1]);
                Encomienda e = new Encomienda(ubicacionx, ubicaciony);
                enco.add(e);
                System.out.println("encomineda " + (j - 2) + " - " + "[" + data.get(j) + "]");
            }

            MatrizDistancia md1 = new MatrizDistancia();
            md1.Matriz(ciudadx, ciudady, paquetes, enco);

            Ejercicio1 e = new Ejercicio1();
            e.entregaPaquetes(md1.matrizC, timerecorrer, paquetes);

        } catch (ExceptionInInitializerError e) {
           // System.out.println("err" + e);
        }
    }

}

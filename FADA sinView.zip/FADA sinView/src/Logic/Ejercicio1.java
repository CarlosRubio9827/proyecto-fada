/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logic;

import Model.Encomienda;
import java.util.ArrayList;
import java.util.Iterator;
import javax.swing.JOptionPane;

/**
 *
 * @author Lenovo
 */
public class Ejercicio1 {

    //  EntradaDatos en = new EntradaDatos();
    ArrayList<Integer> entregas = new ArrayList<>();
    int[] solucion;

    public void entregaPaquetes(int[][] D, int timerecorrer, int paquetes) {
        int[] p = new int[paquetes + 1];
        solucion = new int[p.length];
        solucion[0] = 0;

        for (int i = 0; i < paquetes + 1; i++) {
            p[i] = i;
        }
        entregar(p[0], p, D);
    }

    public int entregar(int actual, int[] p, int[][] D) {
        int tam = p.length;
        if (p.length == 0 || actual == tam - 1) {
            return solucion[actual];
        } else {

            int[] copi = new int[p.length];
            int[] w = new int[p.length - 1];

            for (int i = 0; i < p.length; i++) {
                if (actual != p[i]) {
                    copi[i] = p[i];
                    //    System.out.println("copi" + copi[i]);
                }
            }
            for (int i = 0; i < copi.length - 1; i++) {
                w[i] = copi[i + 1];
                System.out.println("w " + w[i]);
            }

            int min = Integer.MAX_VALUE;

            for (int i = 0; i < w.length; i++) {

                int val = (D[actual][w[i]]) + (entregar(w[i], w, D));

                //   min = (val<min) ? val : min; 
                //  if (val < min) { solucion[i + 1] = w[i];  entregas.add(w[i]); }
                // int temp = D[actual][p[i]]+entregar(p[i+1], w, D);
                min = (val < min) ? val : min;
                solucion[i + 1] = min;
            }
            for (int f = 0; f < entregas.size(); f++) {
                // System.out.print(" - " + entregas.get(f));
            }

            for (int s = 0; s < p.length; s++) {
                //    System.out.print(" - " + solucion[s]);
            }

            return min;
        }
    } 

    public int entregar2(int actual, int entregas, int[] p, int[][] D) {
        int tam = p.length;
        if (p.length == 0 || actual == tam - 1) {
            return solucion[actual];
        } else {
            int min = Integer.MAX_VALUE;

            for (int i = 0; i < entregas; i++) {
                for (int k = 0; k < entregas - i; k++) {

                }

            }

            int[] copi = new int[p.length];
            int[] w = new int[p.length - 1];

            for (int i = 0; i < p.length; i++) {
                if (actual != p[i]) {
                    copi[i] = p[i];
                    //    System.out.println("copi" + copi[i]);
                }
            }
            for (int i = 0; i < copi.length - 1; i++) {
                w[i] = copi[i + 1];
                System.out.println("w " + w[i]);
            }

            for (int i = 0; i < w.length; i++) {

                int val = (D[actual][w[i]]) + (entregar(w[i], w, D));

                //   min = (val<min) ? val : min; 
                //  if (val < min) { solucion[i + 1] = w[i];  entregas.add(w[i]); }
                // int temp = D[actual][p[i]]+entregar(p[i+1], w, D);
      //      for (int f = 0; f < entregas.size(); f++) {
                // System.out.print(" - " + entregas.get(f));
                min = (val < min) ? val : min;
                solucion[i + 1] = min;
            }
            }

            for (int s = 0; s < p.length; s++) {
                //    System.out.print(" - " + solucion[s]);
            }

            return 0;
        }
    }



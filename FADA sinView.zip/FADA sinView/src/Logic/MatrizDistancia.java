package Logic;

import Model.Encomienda;
import java.util.ArrayList;

/**
 *
 * @author Lenovo
 */
public class MatrizDistancia {

    int[][] matrizC;

    public void Matriz(int ciudadx, int ciudady, int paquetes, ArrayList<Encomienda> enco) {
        matrizC = new int[paquetes + 1][paquetes + 1];
        Encomienda en, en1;
        int d, x, y;
        for (int i = 0; i < matrizC.length; i++) {
            en = new Encomienda();
            en = enco.get(i);
            for (int j = 0; j < matrizC.length; j++) {
                en1 = new Encomienda();
                en1 = enco.get(j);
                x = Math.abs(en.getX() - en1.getX());
                y = Math.abs(en.getY() - en1.getY());
                d = x + y;
                matrizC[i][j] = d;
            }
        }
        for (int i = 0; i < matrizC.length; i++) {
            for (int j = 0; j < matrizC.length; j++) {
                System.out.print(matrizC[i][j] + " ");
            }
            System.out.println("");
        }

    }

    public int[][] getMatrizC() {
        return matrizC;
    }

}
